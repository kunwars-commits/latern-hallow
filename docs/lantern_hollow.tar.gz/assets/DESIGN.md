# Lantern Hollow: Game Design Document

Post-AP AI for Games, Unit 3: Haunted Maze AI Game
Team: Aman Pallan, Sohan Kunwar, Danny Zheng
Date: November 24, 2026
Target level: Advanced

---

## 1. Game Overview & Creative Concept

### 1.1 Project Title

Lantern Hollow. Written in Python with Pygame. It also builds for the browser with pygbag, so you can play it without installing anything.

### 1.2 Creative Theme & Narrative Hook

You're a kid out trick-or-treating who cut through the graveyard and got lost in the hedge maze behind it. It's night. All you have is a lantern, so you can see a small circle around you and that's it. Candy glints a little in the dark, the ghosts glow faintly, and somewhere out there you can always see two red pumpkin eyes.

To get out you have to pick up every piece of candy. That unlocks the gate in the bottom-right corner, and then you walk out.

The eyes belong to the Warden, a tall scarecrow in a cloak with a jack-o'-lantern for a head. He's slower than you, so he can't just run you down. Instead he keeps track of how you move (do you keep going straight, do you always turn the same way after going up) and tries to get to where you're headed before you do. The ghosts are the easier threat. They wander, chase you when they notice you, and poke around for a bit when they lose you.

### 1.3 Visual & Audio Aesthetics

Everything is drawn with pygame shapes (circles, polygons, lines). We don't load any image files and there's no sound, so the whole game is just the .py files.

Colors: near-black purple background, dark slate floor, purple-grey stone walls.

- Player: a kid in a purple witch hat holding a little yellow lantern.
- Small NPCs (ghosts): see-through bedsheet ghosts, one each in pale blue, mint, lavender and peach. Their eyes turn red when they're chasing you and become X's when they're stunned, so you can tell what they're doing without debug mode.
- Boss (the Warden): dark cloak, orange pumpkin head. For the first 5 seconds he's a gravestone with a dirt mound in front of it. Then he climbs out.
- Rewards: candy is a wrapped candy in a few different colors. The potion is a small green flask.
- Hazards: a black spider hanging on a thread, and grey cobwebs across the path.

---

## 2. Core Game Mechanics & Rules

### 2.1 Player Controls & Interface

| Key | What it does |
|---|---|
| WASD or arrow keys | Move one tile. Hold to keep walking. |
| F1 or ` (backtick) | Toggle AI debug mode |
| P | Pause |
| R | New maze |
| Esc | In game: back to the menu. On the menu: quit. |

On the game-over screen: R for a new maze, M for the menu, Esc to quit.

Movement is tile by tile but the sprite slides between tiles instead of snapping. One step takes 0.11 s.

Before each run there's a start menu where you set Candy %, Potion %, Spider % and Cobweb % with the arrow keys, plus the number of ghosts (0 to 4, default 3). Odds move in 1% steps. Each one is capped at 40% and all four together can't go past 90%. Next to each slider it shows roughly how many you'll get per maze. Enter starts.

The HUD bar on top shows your hearts, candy collected out of the total, a timer, and whether the gate is locked or open.

### 2.2 Game Rules & Flow

- Starting state: you're in the top-left room of a fresh maze with 3 hearts and 0 candy. The gate (bottom-right) is locked. Ghosts are patrolling and the Warden is still a gravestone.
- Win: collect all the candy, then step on the gate.
- Lose: your hearts hit 0 (ghost touches and spider bites cost 1 each), or the Warden touches you. The Warden is an instant loss no matter how many hearts you have.
- After any hit you get 1.2 s of invincibility and the screen shakes.
- Restart / exit: win or lose, you land on the game-over screen (R / M / Esc). You can also hit R mid-game for a new maze.

---

## 3. Procedural Generation & Probability Worlds

### 3.1 DFS Recursive Backtracking

Grid data structure: the maze is 15 x 11 cells, but we store it as a 31 x 23 tile grid. It's a 2D list of booleans where True means wall. Cell (cx, cy) sits at tile (2cx+1, 2cy+1), so every cell is on an odd,odd tile. The wall between two neighboring cells is the tile halfway between them. For example cells (2,3) and (3,3) are tiles (5,7) and (7,7), and the wall between them is tile (6,7). Tiles are 24 px.

We did it this way so walls are just tiles. Movement, A*, line of sight and drawing all use the same grid and nobody has to think about "wall flags".

Carving (iterative version of recursive backtracking, using our own stack):

1. Start with every tile set to wall. Push cell (0,0), mark it visited, open its tile.
2. Look at the cell on top of the stack and list its neighbors (up, down, left, right) that are inside the grid and not visited.
3. If there are any, pick one at random. Open the wall tile between the two cells and the new cell's tile, mark it visited, push it.
4. If there aren't any, pop. That's the backtrack.
5. Repeat until the stack is empty. At that point every cell has been visited.

Loops: a DFS maze is "perfect", meaning there's exactly one route between any two points. We tried that first and the Warden was either unavoidable (if he was between you and the candy, too bad) or useless (if he wasn't). So after carving we go over the inner wall tiles that separate two cells and knock out each one with a 12% chance. Now there are loops and you can go around him. 12% is tuned by feel.

Reachability: we BFS from the start tile to get every reachable tile. Items, ghosts and the Warden only spawn on reachable room tiles (odd,odd). With DFS everything is reachable anyway, so this is mostly a safety net, but it's cheap.

### 3.2 Probability Table

Every reachable room tile that's at least 4 tiles (Manhattan) from the start and isn't the gate gets one random roll from 0 to 100. The four odds are stacked in order candy, potion, spider, web. With the defaults that means: under 12 is candy, 12 to 15 potion, 15 to 20 spider, 20 to 28 cobweb, and 28 or higher is nothing. So a tile gets at most one thing. If the rolls give zero candy (possible if you set candy really low), we force one candy onto an empty tile so the game still has a goal.

With the defaults that's about 19 candy, 5 potions, 8 spiders and 13 webs per maze.

| Spawn Object | Default % | Variable Name | Effect |
|---|---|---|---|
| Candy | 12% | `odds["candy"]` | +1 toward the gate count. Get all of it and the gate opens. |
| Potion | 3% | `odds["potion"]` | +1 heart (max 3). |
| Spider | 5% | `odds["spider"]` | Bites you for -1 heart. The spider is used up. |
| Cobweb | 8% | `odds["web"]` | You're stuck in place for 0.7 s, then the web breaks. The Warden takes an extra 0.3 s to cross a web tile and counts it as cost 4 in A*. Ghosts float over webs. |

---

## 4. Small NPC AI (FSM)

Each ghost runs a 4-state FSM (ghost.py). Speed depends on the state, in seconds per tile: PATROL 0.32, CHASE 0.17, SEARCH 0.24. Even chasing, they're slower than you (0.11), so a ghost mostly gets you when you walk into it, get cornered, or get stuck in a web.

A ghost "notices" you if either is true:
- Hearing: you're within 2 tiles. Walls don't block this.
- Sight: you're in the same row or column, 7 tiles or less away, with no wall tile in between. They can't see around corners, so turning breaks line of sight.

### 4.1 State-Transition Table

| Current State | Trigger | Action | Next State |
|---|---|---|---|
| PATROL | No path left (just spawned or arrived) | Pick a random room within 8 tiles of its home spot, A* to it | PATROL |
| PATROL | Notices the player | Save last seen tile, shriek | CHASE |
| PATROL | Another ghost shrieks within 14 tiles | Use the shriek spot as its anchor | SEARCH |
| CHASE | Still sees or hears the player | Update last seen tile, re-run A* to it every 0.4 s | CHASE |
| CHASE | 1.5 s without seeing or hearing the player | Anchor on the last seen tile | SEARCH |
| SEARCH | Not at anchor yet | A* to the anchor | SEARCH |
| SEARCH | At anchor, path done | Wander to a random tile within 3 of the anchor | SEARCH |
| SEARCH | Notices the player | Save last seen tile, shriek | CHASE |
| SEARCH | 5 s in this state | Give up | PATROL |
| PATROL / CHASE / SEARCH | Touches the player | Player loses a heart (unless invincible), ghost freezes | STUNNED |
| STUNNED | 2 s pass | Unfreeze | PATROL |

The shriek is how the ghosts cooperate. They don't get your position forever, just where you were when you got spotted, so it's more like the nearby ghosts drifting toward that area.

### 4.2 Pathfinding

Algorithm: A* (astar.py), shared by the ghosts and the Warden.

- Open list is a binary heap (heapq) ordered by f = g + h. Ties go to the lower h.
- h is Manhattan distance, |dx| + |dy|.
- Closed set, so a tile is never expanded twice. Stale heap entries just get skipped when popped.
- `parent` dict maps each tile to the tile we reached it from.
- Ghosts pay cost 1 per tile. The Warden passes in a different cost function (section 5.2).
- It returns a `Route`: the path, the total cost g, and the set of explored tiles. The explored set is only used by debug mode.

Path reconstruction: when the goal comes off the heap, we start at the goal and follow `parent` back until we hit the start, then reverse the list. The first entry is the NPC's own tile, so it drops that. After that, every time it finishes moving one tile it pops the next one off the front.

---

## 5. Predictive Analytics & Boss AI

The Warden moves at 0.20 s per tile and you move at 0.11. If he just chased you he'd never catch you. He has to guess where you're going and get there first, which is what this section is about.

### 5.1 First-order Markov Model

State space: your last move, S = {U, D, L, R}. Only real moves count. Walking into a wall doesn't change anything.

Every time you move a tile we do `first[prev][new] += 1`. We also keep a second-order (2-gram) table keyed by your last two moves (more on that in section 7).

Transition matrix sketch with example counts (rows = previous move, columns = next move). The real one is live in the debug panel:

| prev \ next | U | D | L | R |
|---|---|---|---|---|
| U | 18 | 1 | 5 | 7 |
| D | 0 | 21 | 6 | 9 |
| L | 4 | 7 | 15 | 1 |
| R | 3 | 6 | 1 | 14 |

The diagonal is big because people keep going the same way, and reversing is rare. Part of that is the maze itself (a corridor only leaves you two options), which is why we only score legal moves.

Prediction rule:
1. If the 2-gram row for your last two moves has at least 3 samples, use it. Otherwise use the first-order row for your last move. If that's empty too (start of the game), every move is equal.
2. Only directions that aren't walls from your current tile are considered.
3. Each legal direction gets count + 0.5, then we divide by the total.
4. The highest probability is the prediction.

Example: your last move was R and the tile above you is a wall, so D, L and R are legal. From the R row: D = 6.5, L = 1.5, R = 14.5, total 22.5. That gives P(R) = 0.64, P(D) = 0.29, P(L) = 0.07, so the prediction is R at 64%.

The +0.5 keeps a move you've never made from having 0% chance.

We also track accuracy. After each move we check if the last prediction was right, both for the model actually being used and for first-order on its own.

### 5.2 Ambush Pipeline

The Warden is DORMANT for the first 5 s. After that he rethinks every 0.5 s:

1. Forecast. Put probability 1.0 on your tile and roll the model forward 10 steps. Each step, every branch splits its probability across the legal moves from its tile, using the same rule as above (each branch remembers its own last two moves). Branches under 0.3% get dropped so it doesn't blow up.
2. Candidate extraction. For each of the 10 steps, take the single most likely tile. Those are the ambush candidates (duplicates skipped). Your current tile is added as the "chase" candidate.
3. A* from the Warden to every candidate. His cost map: cobweb tiles cost 4, everything else costs 1. So he goes around webs unless the detour is longer than that.
4. Score each candidate:
   - Ambush: `U = 100*P - 2*cost - 6*late`
   - `late = max(0, cost*0.20 - k*0.11)`, where k is how many steps ahead the tile is. cost*0.20 is roughly his travel time and k*0.11 is yours if you walk nonstop, so late is how many seconds after you he'd show up.
   - Chase: `U = 35 - 2*cost`
   - Waiting penalty: if the candidate is the tile he's already standing on, subtract 15 for every second he's been waiting there.
   - If A* can't reach a candidate it gets -infinity.
5. Highest U wins. He follows that A* path until the next rethink.

Example of how one decision can go:

| Candidate | k | P | cost | late | U |
|---|---|---|---|---|---|
| Ambush tile A | 3 | 0.55 | 13 | 2.27 | 15.4 |
| Ambush tile B | 7 | 0.41 | 6 | 0.43 | 26.4 |
| Chase (your tile) | 0 | 1.00 | 14 | 0 | 7.0 |

Tile B wins even though it's less likely, because he can actually get there in time.

Why 35 for chase: your current tile is certain, but if chase was worth 100 he'd always chase, and he's too slow for that to work. At 35 chasing only wins when he's already close. This was tuned by feel. The late math is rough too. It assumes you never stop, which nobody does, but it still pushes him toward tiles he can reach in time.

A* heuristic: Manhattan, same as the ghosts. Every tile costs at least 1, so Manhattan never overestimates and A* still finds the cheapest path even with the web costs.

His state label comes straight out of the decision:
- DORMANT: first 5 s, still a gravestone.
- HUNT: the chase candidate won.
- INTERCEPT: heading to an ambush tile.
- AMBUSH: standing on the ambush tile, waiting.

---

## 6. AI Debug Mode

### 6.1 What's Drawn

Press F1 or backtick. The darkness mostly lifts so you can see the whole maze.

Ghosts:
- each ghost's path as a line in its own color
- an X on its current target tile
- a small tag above its head with its state

Warden:
- a purple heat map of the 10-step forecast (each tile shaded by its highest probability across the 10 steps)
- a yellow square on every candidate with its U score written inside. The winner gets a white outline.
- his chosen route as a red line, and the tiles A* explored for it as faint red dots
- his state tag above his head

Player: a purple arrow pointing at the predicted next move, with its %.

Side panel (right side):
- Player model: last few moves, which model is in use (2-gram / 1st-order / uniform), probability bars for U/D/L/R (or "wall"), the 4x4 first-order count matrix, and hit rate for the active model vs first-order only.
- Warden: state, rethink timer (x / 0.50 s), target tile, path cost g, h, nodes explored, the scoring formula, and a table of candidates (tile, steps ahead, P, cost, late, U) sorted by score with the winner highlighted.
- Ghosts: one line each with state, target and path length.

With debug off, the panel shows how to play and a legend for the items.

### 6.2 Code Architecture

- `settings.py`: sizes, speeds, colors, default odds.
- `maze.py`: `Maze`. DFS carving, adding loops, open tiles and exits, line of sight, BFS reachability.
- `astar.py`: `astar()` and the `Route` it returns.
- `markov.py`: `Predictor`. First-order and 2-gram counts, the probability distribution, the 10-step forecast, accuracy tracking.
- `actors.py`: `Mover` base class (smooth tile-to-tile movement) and `Player`.
- `ghost.py`: `Ghost`, the FSM.
- `warden.py`: `Warden` and `Option` (one scored candidate).
- `world.py`: `World`. Builds the maze, rolls items, picks spawn spots (ghosts at least 10 tiles from the start, the Warden at least 20).
- `draw.py`: `Painter`. All drawing: sprites, darkness, HUD, debug overlay, side panels, menu.
- `main.py`: `Game`. Menu / play / game-over modes, input, collisions. The main loop is async so pygbag can run it in a browser.

---

## 7. Advanced Extensions

1. Second-order (2-gram) prediction. We also count what you do after each pair of moves, and use that row once it has 3+ samples. The panel shows its hit rate next to first-order alone, so you can see live whether it's actually helping.
2. Different terrain costs per NPC. Webs cost 4 in the Warden's A* (and really do slow him by 0.3 s), so he avoids them. Ghosts float over webs and pay 1 everywhere.
3. Cooperating ghosts. The shriek pulls patrolling ghosts within 14 tiles into SEARCH at the spot where you were seen.
4. Utility scoring with a waiting penalty. One score decides between chasing and up to 10 ambush tiles, instead of hard-coded rules. Without the -15/s penalty, if you just stood still the forecast wouldn't change and he'd camp the same tile forever.

---

## 8. Milestones

| # | Checkpoint | Evidence | Date | Teacher Initials |
|---|---|---|---|---|
| 1 | Maze generation: DFS carve, loops, BFS reachability | Screenshots of a few different mazes, maze.py | Nov 3, 2026 | |
| 2 | Player movement, items rolled from the odds, hearts and candy | Playable build, HUD showing hearts and candy | Nov 5, 2026 | |
| 3 | A* working, ghosts patrolling | Debug lines showing ghost paths | Nov 9, 2026 | |
| 4 | Full ghost FSM (chase, search, stunned, shriek) | Video of the state tags changing | Nov 12, 2026 | |
| 5 | Markov predictor and the debug side panel | Count matrix and prediction arrow on screen | Nov 16, 2026 | |
| 6 | Warden forecast + ambush scoring | Candidate scores and red route in debug mode | Nov 19, 2026 | |
| 7 | Lantern darkness, art pass, start menu, pygbag web build | Web build running in the browser | Nov 23, 2026 | |
| 8 | Final playtest, tuning, this GDD | Final build + DESIGN.md | Nov 24, 2026 | |

---

## 9. AI Design Diagram

Ghost FSM:

```mermaid
stateDiagram-v2
    [*] --> PATROL
    PATROL --> CHASE: sees or hears player (shrieks)
    PATROL --> SEARCH: another ghost shrieked within 14 tiles
    CHASE --> SEARCH: lost player for 1.5 s
    SEARCH --> CHASE: sees or hears player (shrieks)
    SEARCH --> PATROL: 5 s with nothing
    PATROL --> STUNNED: touches player
    CHASE --> STUNNED: touches player
    SEARCH --> STUNNED: touches player
    STUNNED --> PATROL: after 2 s
```

Warden decision pipeline (the Markov counts update on every player move, the rest runs every 0.5 s):

```mermaid
flowchart TD
    A[Observe player move] --> B[Update Markov counts]
    B --> C[Forecast 10 steps ahead]
    C --> D[Candidates: top tile per step + player's tile]
    D --> E[A* to each candidate]
    E --> F[Score U for each]
    F --> G[Pick highest U]
    G --> H[Follow that A* path]
    H -->|every 0.5 s| A
```
