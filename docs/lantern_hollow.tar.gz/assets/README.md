# Lantern Hollow

Unit 3 Haunted Maze AI project. Aman Pallan, Sohan Kunwar, Danny Zheng.

You're a kid lost in a graveyard hedge maze at night with only a lantern. Grab every piece of candy to unlock the gate in the bottom-right corner, then get out. Ghosts wander the maze, and the Warden (a scarecrow with a pumpkin head) learns how you move and tries to cut you off.

## Running it

```
pip install pygame-ce
python main.py
```

Regular `pygame` works too.

The web version is in `docs/` (built with pygbag) and runs on GitHub Pages. Click the game once so it gets keyboard focus. In the browser, use ` for debug because F1 opens the browser's help page.

## Controls

| Key | |
|---|---|
| WASD / arrow keys | move |
| F1 or ` | AI debug mode |
| P | pause |
| R | new maze |
| Esc | menu (quits from the menu) |

On the start menu, Up/Down picks a row and Left/Right changes it. You set the candy, potion, spider and cobweb odds and how many ghosts there are, then press Enter.

## Rules

- Candy: collect all of it to open the gate.
- Potion: +1 heart (max 3).
- Spider: -1 heart.
- Cobweb: stuck for 0.7 s.
- Ghost touch: -1 heart, and the ghost is stunned for 2 s.
- Warden touch: you lose right away.

## AI used

- DFS recursive backtracking (with a stack) carves the maze, then about 12% of the inner walls get knocked out so there are loops. BFS checks reachability before anything spawns.
- The probabilities from the menu are rolled once per room tile when the maze is built.
- Ghosts run an FSM with PATROL, CHASE, SEARCH and STUNNED. Every move they make goes through A*.
- A* uses a Manhattan heuristic and returns the path, the cost and the explored tiles.
- A Markov model counts your move-to-move transitions (U/D/L/R), plus a 2-gram table for the last two moves. It only looks at directions that aren't walls.
- Every 0.5 s the Warden rolls the Markov model 10 steps ahead. It takes the most likely tile at each step and scores it as `U = 100P - 2cost - 6late`, against plain chasing (`35 - 2cost`). Then it walks the winning A* path.

Turn on debug mode to see all of it: the forecast heat map, the candidate tiles with their scores, every path, the FSM states, the transition matrix and how often the prediction is right.

## Extensions

- 2-gram prediction, with its hit rate shown next to first-order in the debug panel
- different terrain costs per NPC: the Warden treats webs as cost 4 and they really do slow it down, while ghosts ignore them
- ghosts call each other: when one spots you, nearby patrolling ghosts go search there
- utility scoring with a waiting penalty so the Warden doesn't camp one tile forever

## Known limitations

- The Warden always knows where you are. It only has to guess where you're going.
- The lateness math assumes you never stop walking.
- No sound.
- All the weights (100, 2, 6, 35, 15) were picked by playing, not by any real optimization.
- Line of sight is straight lines only (same row or column), so ghosts can't see you diagonally.
